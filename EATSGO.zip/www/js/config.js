var krms_config ={						
	'ApiUrl':"http://eatsgo.com.br/mobileappv2/api",
	'AppTitle':"EATSGO",
	'ApiKey' : 'eatsgo@1234',
	'debug': false
};